# Scientific controls

{
  "status": "success",
  "checks": [
    {
      "name": "omit_cell_dilution",
      "passed": true,
      "score": 10,
      "failed_gates": [
        "base:rates_and_effects",
        "base:intervals",
        "base:classes",
        "base:group_contrasts",
        "early_window:rates_and_effects",
        "early_window:intervals",
        "early_window:classes",
        "early_window:group_contrasts",
        "leave_parent_out:rates_and_effects",
        "leave_parent_out:intervals",
        "leave_parent_out:classes",
        "leave_parent_out:group_contrasts"
      ]
    },
    {
      "name": "assume_complete_transcription_block",
      "passed": true,
      "score": 10,
      "failed_gates": [
        "base:rates_and_effects",
        "base:intervals",
        "base:classes",
        "base:group_contrasts",
        "early_window:rates_and_effects",
        "early_window:intervals",
        "early_window:classes",
        "early_window:group_contrasts",
        "leave_parent_out:rates_and_effects",
        "leave_parent_out:intervals",
        "leave_parent_out:classes",
        "leave_parent_out:group_contrasts"
      ]
    },
    {
      "name": "treat_fractions_as_pure",
      "passed": true,
      "score": 10,
      "failed_gates": [
        "base:rates_and_effects",
        "base:intervals",
        "base:classes",
        "base:group_contrasts",
        "early_window:rates_and_effects",
        "early_window:intervals",
        "early_window:classes",
        "early_window:group_contrasts",
        "leave_parent_out:rates_and_effects",
        "leave_parent_out:intervals",
        "leave_parent_out:classes",
        "leave_parent_out:group_contrasts"
      ]
    }
  ],
  "scope": "Wrong-method numerical controls, not external model attempts."
}
