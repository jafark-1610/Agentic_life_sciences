# Rubric

* policy_decision: 40 points.
* sharp_bounds: 35 points.
* global_envelopes: 15 points.
* identification: 10 points.

All scientific groups are gates and group credit is all-or-nothing. Any scientific failure caps at 79. Presentation recovery is applied before science and costs 5 once without activating a gate. Missing/inconsistent analysis diagnostics cost 5. Caps precede deductions. Scores are floored at zero; pass threshold is 80 inclusive. No other score rules apply. IDs determine alignment; every array ordering is accepted. Any qualifying policy within public decision slack of the optimal resource-adjusted score is accepted.

Actual submitted source must run offline in isolation and pass on both base and regenerated population tables. Infrastructure capability failure is BLOCKED, not a solver failure. Failed scientific rerun prevents acceptance and caps at 79.

Automatic zero: absent/unreadable/duplicate-key/nonfinite answer JSON; missing or non-running pipeline during full verification.

Required deliverables: run_pipeline.py, final_answer.json, analysis.md.

Full grading: `python expert_solution/verify_submission.py --solver PATH --data task/data --output-dir OUTPUT --replay-control`.

## Machine-readable policy

```json
{
  "case_id": "ALS_PAIRED_IMMUNITY_003",
  "version": "1.0",
  "weights": {
    "policy_decision": 40,
    "sharp_bounds": 35,
    "global_envelopes": 15,
    "identification": 10
  },
  "pass_threshold": 80,
  "scientific_failure_cap": 79,
  "presentation_deduction": 5,
  "delivery_deduction": 5,
  "automatic_zero": [
    "absent/unreadable/duplicate-key/nonfinite answer JSON",
    "missing or non-running pipeline during full verification"
  ],
  "execution_gate": "Actual submitted source must run offline in isolation and pass on both base and regenerated population tables. Infrastructure capability failure is BLOCKED, not a solver failure. Failed scientific rerun prevents acceptance and caps at 79.",
  "required_deliverables": [
    "run_pipeline.py",
    "final_answer.json",
    "analysis.md"
  ],
  "tolerances": {
    "numeric_absolute": 0.001,
    "decision_slack": 0.001,
    "identification_width": 0.0001,
    "policy_score_absolute": 0.002
  },
  "numeric_tolerance": 1e-05,
  "numeric_tolerance_scope": "Oracle cross-runtime comparison fallback only; scientific solver tolerance remains the public numeric_absolute.",
  "path_tolerances": {
    "/contexts/*/policies/*/eligibility_lower": 0.001,
    "/contexts/*/policies/*/eligibility_upper": 0.001,
    "/contexts/*/policies/*/net_gain_lower": 0.001,
    "/contexts/*/policies/*/net_gain_upper": 0.001,
    "/contexts/*/policies/*/harm_upper": 0.001,
    "/contexts/*/policies/*/cost_upper": 0.001,
    "/global_policies/*/worst_net_gain": 0.001,
    "/global_policies/*/worst_harm": 0.001,
    "/global_policies/*/worst_cost": 0.001,
    "/global_policies/*/minimum_eligibility": 0.001,
    "/global_policies/*/resource_adjusted_score": 0.002
  },
  "dimensions": {
    "contexts": 3,
    "policies": 24
  },
  "field_contract": {
    "sharp_bounds": "prompt.md: Policy worlds and target quantities",
    "identification": "prompt.md: Policy worlds and target quantities",
    "policy_decision": "prompt.md: Policy worlds and target quantities",
    "global_envelopes": "prompt.md: Policy worlds and target quantities",
    "delivery": "prompt.md: Execution and output"
  },
  "policy": "All scientific groups are gates and group credit is all-or-nothing. Any scientific failure caps at 79. Presentation recovery is applied before science and costs 5 once without activating a gate. Missing/inconsistent analysis diagnostics cost 5. Caps precede deductions. Scores are floored at zero; pass threshold is 80 inclusive. No other score rules apply. IDs determine alignment; every array ordering is accepted. Any qualifying policy within public decision slack of the optimal resource-adjusted score is accepted.",
  "full_grading_command": "python expert_solution/verify_submission.py --solver PATH --data task/data --output-dir OUTPUT --replay-control"
}
```
